package com.in28minutes.rest.webservices.restfulwebservices.articuloas;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;


@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ArticulosJpaResource {
	
	

	@Autowired
	private ArticulosRepository articulosRepository       ;

	//	//http://localhost:8080/jpa/articulos/users/articulos

	@GetMapping("/jpa/articulos/users/articulos")// /jpa/articulos/users/articulos
	//	@GetMapping("/jpa/articulos/users/{username}/todos")

	public List<Articulos> getAllTodos(){
		//	public List<Articulos> getAllTodos(@PathVariable String username){

		//return articulosRepository.findByUsername(username);
		return articulosRepository.findAll();

		//return todoService.findAll();
	}

	@GetMapping("/jpa/articulos/users/articulos/{id}")
	//	@GetMapping("/jpa/articulos/users/{username}/todos/{id}")

	public Articulos getTodo(@PathVariable String id){
	//	public Articulos getTodo(@PathVariable String username, @PathVariable String id){
	
		return articulosRepository.findById(id).get();
		//return todoService.findById(id);
	}

	// DELETE /users/{username}/todos/{id}
	@DeleteMapping("/jpa/articulos/users/articulos/{id}")
	//	@DeleteMapping("/jpa/articulos/users/{username}/todos/{id}")

	public ResponseEntity<Void> deleteTodo(@PathVariable String id) {
//	public ResponseEntity<Void> deleteTodo(@PathVariable String username, @PathVariable String id) {

		articulosRepository.deleteById(id);

		return ResponseEntity.noContent().build();
	}
	

	//Edit/Update a Todo
	//PUT /users/{user_name}/todos/{todo_id}
	@PutMapping("/jpa/articulos/users/articulos/{id}")
	//	@PutMapping("/jpa/articulos/users/{username}/todos/{id}")

public ResponseEntity<Articulos> updateTodo
(@PathVariable String id, @RequestBody Articulos  articulos ){
		//public ResponseEntity<Articulos> updateTodo(@PathVariable String username,@PathVariable String id, @RequestBody Articulos  articulos ){
		
		//articulos.setUsername(username);
		
		Articulos todoUpdated = articulosRepository.save(articulos);
		
		return new ResponseEntity<Articulos>(todoUpdated, HttpStatus.OK);
	}
	//INSERT crear nuevos registros en tablas
	@PostMapping("/jpa/articulos/users/articulos")
//	@PostMapping("/jpa/articulos/users/{username}/todos")

	public ResponseEntity<Void> createTodo( @RequestBody Articulos  articulos){
//	public ResponseEntity<Void> createTodo(@PathVariable String username, @RequestBody Articulos  articulos){
		
		//articulos.setUsername(username);
		
		Articulos createdTodo = articulosRepository.save(articulos);
		
		//Location
		//Get current resource url
		///{id}
		URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
				.path("/{id}").buildAndExpand(createdTodo.getUsername()).toUri();
		
		return ResponseEntity.created(uri).build();
	}
		
}
