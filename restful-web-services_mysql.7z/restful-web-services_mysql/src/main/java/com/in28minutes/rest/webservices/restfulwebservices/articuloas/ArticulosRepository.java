package com.in28minutes.rest.webservices.restfulwebservices.articuloas;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;



// no es todo
public interface ArticulosRepository extends JpaRepository<Articulos, String> {

	// that's it ... no need to write any code LOL!
   Optional<Articulos> findById(String username);
	List<Articulos> findByUsername(String username);


}