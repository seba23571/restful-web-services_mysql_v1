insert into todo(id, username,description,target_date,is_done)
values(10001, 'supraweb', 'Learn JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10002, 'supraweb', 'Learn Data JPA', sysdate(), false);

insert into todo(id, username,description,target_date,is_done)
values(10003, 'supraweb', 'Learn Microservices', sysdate(), false);